module com.example.test2part2 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;
    requires com.almasb.fxgl.all;

    opens com.example.test2part2 to javafx.fxml;
    exports com.example.test2part2;
}